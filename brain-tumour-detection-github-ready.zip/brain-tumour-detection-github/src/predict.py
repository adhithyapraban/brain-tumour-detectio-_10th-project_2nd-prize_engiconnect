"""
Predict whether a brain MRI image has a tumour.

Usage:
python src/predict.py --model model/bestmodel.h5 --image path/to/image.jpg
"""

import argparse

import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import img_to_array, load_img


IMG_SIZE = (224, 224)


def predict_image(model_path: str, image_path: str) -> float:
    """Return prediction score between 0 and 1."""
    model = load_model(model_path)

    img = load_img(image_path, target_size=IMG_SIZE)
    input_arr = img_to_array(img) / 255.0
    input_arr = np.expand_dims(input_arr, axis=0)

    prediction = model.predict(input_arr)[0][0]
    return float(prediction)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, required=True, help="Path to trained model")
    parser.add_argument("--image", type=str, required=True, help="Path to MRI image")
    args = parser.parse_args()

    score = predict_image(args.model, args.image)

    print(f"Prediction score: {score:.4f}")

    if score >= 0.5:
        print("Result: Tumour detected")
    else:
        print("Result: No tumour detected")


if __name__ == "__main__":
    main()
