"""
Train a CNN model for brain tumour detection.

Expected dataset structure:
brain_tumor_dataset/
    yes/
    no/
"""

import argparse
import os
from pathlib import Path

import tensorflow as tf
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
from tensorflow.keras.layers import Conv2D, Dense, Dropout, Flatten, MaxPool2D
from tensorflow.keras.models import Sequential
from tensorflow.keras.preprocessing.image import ImageDataGenerator


IMG_SIZE = (224, 224)
BATCH_SIZE = 32


def build_model() -> Sequential:
    """Build and compile the CNN model."""
    model = Sequential([
        Conv2D(16, (3, 3), activation="relu", input_shape=(224, 224, 3)),

        Conv2D(36, (3, 3), activation="relu"),
        MaxPool2D(pool_size=(2, 2)),

        Conv2D(64, (3, 3), activation="relu"),
        MaxPool2D(pool_size=(2, 2)),

        Conv2D(128, (3, 3), activation="relu"),
        MaxPool2D(pool_size=(2, 2)),

        Dropout(0.25),
        Flatten(),

        Dense(64, activation="relu"),
        Dropout(0.25),

        Dense(1, activation="sigmoid"),
    ])

    model.compile(
        optimizer="adam",
        loss="binary_crossentropy",
        metrics=["accuracy"],
    )

    return model


def create_generators(data_dir: str):
    """Create train, validation, and test generators from folders."""
    train_datagen = ImageDataGenerator(
        rescale=1 / 255,
        validation_split=0.30,
        zoom_range=0.2,
        shear_range=0.2,
        horizontal_flip=True,
    )

    test_val_datagen = ImageDataGenerator(
        rescale=1 / 255,
        validation_split=0.30,
    )

    train_data = train_datagen.flow_from_directory(
        data_dir,
        target_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        class_mode="binary",
        subset="training",
    )

    val_data = test_val_datagen.flow_from_directory(
        data_dir,
        target_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        class_mode="binary",
        subset="validation",
    )

    return train_data, val_data


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", type=str, required=True, help="Path to dataset folder")
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--model_dir", type=str, default="model")
    args = parser.parse_args()

    Path(args.model_dir).mkdir(exist_ok=True)

    train_data, val_data = create_generators(args.data_dir)

    print("Class indices:", train_data.class_indices)

    model = build_model()
    model.summary()

    checkpoint_path = os.path.join(args.model_dir, "bestmodel.h5")

    callbacks = [
        EarlyStopping(
            monitor="val_accuracy",
            min_delta=0.01,
            patience=6,
            verbose=1,
            restore_best_weights=True,
        ),
        ModelCheckpoint(
            filepath=checkpoint_path,
            monitor="val_accuracy",
            verbose=1,
            save_best_only=True,
        ),
    ]

    history = model.fit(
        train_data,
        epochs=args.epochs,
        validation_data=val_data,
        callbacks=callbacks,
    )

    print(f"Best model saved to: {checkpoint_path}")


if __name__ == "__main__":
    main()
